#include <tsh.h>
#include <iostream>
#include <sys/wait.h>
#include <string.h>
#include <fcntl.h>
#include <fstream>

using namespace std;


void simple_shell::parse_command(char* cmd, char** cmdTokens) {
  // TODO: tokenize the command string into arguments
  char *token = strtok(cmd, " \n");
  int i = 0;
  while(token != NULL){
    cmdTokens[i] =  token;
    token = strtok(NULL, " \n");
    i = i + 1;
    /* if(i == sizeof(token)){
      cmdTokens[i] = NULL;
      //token = NULL;
      continue;
      }*/
  }
  cmdTokens[i] = NULL;
}

void simple_shell::exec_command(char** argv) {
    // TODO: fork a child process to execute the command.
    // parent process should wait for the child process to complete and reap it
  int pipe_idx = -1; 
  int redirect_idx = -1;
  int i = 0;
  while(argv[i] != NULL){ //get index of pipe
    if(strcmp(argv[i], "|") == 0){
      pipe_idx = i;
      break;
    }
    else if(strcmp(argv[i], ">") == 0){
      redirect_idx = i;
      break;
    }
    i++;
  }
  if(pipe_idx != -1){ //if pipe exists
    argv[pipe_idx] = NULL; 
    int fd[2]; //declare file descriptor
    if(pipe(fd) == -1){ //if pipe doesnt work
      perror("pipe failed");
      exit(0);
    } 
    int pid = fork();
    if(pid == -1){
      perror("fork failed");
      exit(0);
    }
    else if(pid == 0){// child process
      close(fd[0]);
      dup2(fd[1], STDOUT_FILENO);
      close(fd[1]);
      execvp(argv[0], argv);
      perror("execvp for command 1 failed");
    }
    close(fd[1]);
    dup2(fd[0], STDIN_FILENO);
    close(fd[0]);
    char** argv2 = argv + pipe_idx + 1; //stores commands after pipe
    execvp(argv2[0], argv2);
    perror("execvp for command 2 failed");
    exit(0);
  }
  else if (redirect_idx != -1) { // If redirection exists
    argv[redirect_idx] = NULL;
    char* filename = argv[redirect_idx + 1]; // Get the filename after '>'
    int fd = open(filename, O_WRONLY);
    if (fd == -1) {
        perror("open failed");
        exit(0);
    }
    dup2(fd, STDOUT_FILENO); // redirect stdout to file
    close(fd);
    execvp(argv[0], argv);
    perror("execvp failed");
    exit(0);
  }
  else { //not a pipe
    if (cmdHandler(argv) != 0) { // check for additional commands
              return;
          }
      int pid = fork();
      if(pid == -1){
        perror("fork failed");
        exit(0);
      } 
      else if(pid == 0){
        execvp(argv[0], argv);
        perror("execvp failed");
        exit(0);
      }
      else{ 
        //waitpid(pid, NULL, WNOHANG);
        wait(NULL);
      } 
    }
}
int simple_shell::cmdHandler(char** argv) {
    int num_cmds = 4;
    int cmd_idx = 0;
    const char* cmds[num_cmds];

    cmds[0] = "pwd";
    cmds[1] = "cd";
    cmds[2] = "help";
    cmds[3] = "tim";

    for (int i = 0; i < num_cmds; i++) {
    if (strcmp(argv[0], cmds[i]) == 0) {
        cmd_idx = i + 1;
        break;
    }
}

switch (cmd_idx) {
    case 1:  
        char cwd[PATH_MAX];
        getcwd(cwd,sizeof(cwd)); 
        std::cout << cwd << std::endl;                                                                            
        return 1;
    case 2:
        chdir(argv[1]);
        return 1;
    case 3:
        openHelp();
        return 1;
    case 4:
        /*argv[0] = "cat";
        argv[1] = "tim.txt";
        argv[3] = NULL;
        execvp(argv[0], argv);*/
        printf("  _______ _             _       _   _            _               _   _ \n");
        printf(" |__   __(_)           (_)     | | | |          | |             | | | |\n");
        printf("    | |   _ _ __ ___    _ ___  | |_| |__   ___  | |__   ___  ___| |_| |\n");
        printf("    | |  | | '_ ` _ \\  | / __| | __| '_ \\ / _ \\ | '_ \\ / _ \\/ __| __| |\n");
        printf("    | |  | | | | | | | | \\__ \\ | |_| | | |  __/ | |_) |  __/\\__ \\ |_|_|\n");
        printf("    |_|  |_|_| |_| |_| |_|___/  \\__|_| |_|\\___| |_.__/ \\___||___/\\__(_)\n\n");
          return 1;
    default:
        break;
}
return 0;
}

void simple_shell::openHelp()
{
    puts("\n***WELCOME TO SANJANA'S SHELL HELP***"
        "\nCopyright @ Sanjana Sitaraman"
        "\nList of Commands supported:"
        "\n>>> general commands available in UNIX shell"
        "\n>>> pipe handling"
        "\n>>> redirection handling"
        "\n>>> pwd: prints current working directory"
        "\n>>> cd: navigates to specific directory"
        "\n>>> help: information on shell capabilities"
        "\n>>> tim: a special command- try it out to find out what it does!");
    return;
}
    

bool simple_shell::isQuit(char* cmd) {
    // TODO: check for the command "quit" that terminates the shell
  if(strcmp(cmd, "quit") == 0){
    return true;
  }
  return false;
}
